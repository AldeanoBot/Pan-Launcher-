﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Windows.Forms.Application]::EnableVisualStyles()

$bundleZip = Join-Path $PSScriptRoot 'app-bundle.zip'
$baseDir = Join-Path $env:LOCALAPPDATA 'Pan-launcher'
$binDir = Join-Path $baseDir 'appbin'
$verPath = Join-Path $baseDir 'version.txt'

$bg = [System.Drawing.Color]::FromArgb(11, 13, 16)
$barBg = [System.Drawing.Color]::FromArgb(16, 19, 24)
$cardBg = [System.Drawing.Color]::FromArgb(18, 22, 28)
$emerald = [System.Drawing.Color]::FromArgb(16, 185, 129)
$darkText = [System.Drawing.Color]::FromArgb(5, 18, 12)
$muted = [System.Drawing.Color]::FromArgb(180, 188, 200)

$form = New-Object System.Windows.Forms.Form
$form.Text = "Instalador de Pan-launcher"
$form.ClientSize = New-Object System.Drawing.Size(620, 420)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = $bg
$form.ForeColor = [System.Drawing.Color]::White

$hdr = New-Object System.Windows.Forms.Panel
$hdr.SetBounds(0, 0, 620, 64)
$hdr.BackColor = $barBg
$form.Controls.Add($hdr)

$hdrLbl = New-Object System.Windows.Forms.Label
$hdrLbl.SetBounds(24, 18, 572, 28)
$hdrLbl.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$hdrLbl.ForeColor = $emerald
$hdrLbl.Text = "Pan-launcher  ·  Asistente de instalacion en Windows (4 pasos)"
$hdr.Controls.Add($hdrLbl)

$titleLbl = New-Object System.Windows.Forms.Label
$titleLbl.SetBounds(28, 86, 564, 34)
$titleLbl.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
$titleLbl.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($titleLbl)

$bodyLbl = New-Object System.Windows.Forms.Label
$bodyLbl.SetBounds(28, 128, 564, 110)
$bodyLbl.Font = New-Object System.Drawing.Font("Segoe UI", 10.5)
$bodyLbl.ForeColor = $muted
$form.Controls.Add($bodyLbl)

$chkDesktop = New-Object System.Windows.Forms.CheckBox
$chkDesktop.SetBounds(28, 196, 564, 28)
$chkDesktop.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$chkDesktop.Text = "Crear acceso directo en el Escritorio (Pan-launcher)"
$chkDesktop.Checked = $true
$chkDesktop.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($chkDesktop)

$chkMenu = New-Object System.Windows.Forms.CheckBox
$chkMenu.SetBounds(28, 232, 564, 28)
$chkMenu.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$chkMenu.Text = "Anadir al Menu Inicio de Windows"
$chkMenu.Checked = $true
$chkMenu.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($chkMenu)

$chkLaunch = New-Object System.Windows.Forms.CheckBox
$chkLaunch.SetBounds(28, 268, 564, 28)
$chkLaunch.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$chkLaunch.Text = "Abrir Pan-launcher al finalizar"
$chkLaunch.Checked = $true
$chkLaunch.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($chkLaunch)

$prog = New-Object System.Windows.Forms.ProgressBar
$prog.SetBounds(28, 210, 564, 22)
$prog.Style = "Continuous"
$form.Controls.Add($prog)

$ftr = New-Object System.Windows.Forms.Panel
$ftr.SetBounds(0, 354, 620, 66)
$ftr.BackColor = $barBg
$form.Controls.Add($ftr)

$btnBack = New-Object System.Windows.Forms.Button
$btnBack.SetBounds(28, 15, 110, 36)
$btnBack.FlatStyle = "Flat"
$btnBack.BackColor = $cardBg
$btnBack.ForeColor = [System.Drawing.Color]::White
$btnBack.Text = "Atras"
$ftr.Controls.Add($btnBack)

$btnNext = New-Object System.Windows.Forms.Button
$btnNext.SetBounds(432, 15, 160, 36)
$btnNext.FlatStyle = "Flat"
$btnNext.BackColor = $emerald
$btnNext.ForeColor = $darkText
$btnNext.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$ftr.Controls.Add($btnNext)

$script:step = 0
$script:launchCmdTarget = ""

function Update-StepUi {
  $chkDesktop.Visible = ($script:step -eq 1)
  $chkMenu.Visible = ($script:step -eq 1)
  $chkLaunch.Visible = ($script:step -eq 1 -or $script:step -eq 3)
  $prog.Visible = ($script:step -eq 2)
  $btnBack.Visible = ($script:step -eq 1)
  $btnNext.Enabled = ($script:step -ne 2)
  if ($script:step -eq 0) {
    $titleLbl.Text = "Paso 1 de 4 · Bienvenida"
    $bodyLbl.Text = "Este asistente instalara Pan-launcher en tu PC (AppData\Local\Pan-launcher) sin usar pestanas de Chrome.`r`n`r`n1. Extrae la aplicacion y el servidor local de Minecraft Java.`r`n2. Configura ventana propia (Edge App / WebView2).`r`n3. Crea el acceso directo en tu Escritorio."
    $btnNext.Text = "Siguiente ->"
  } elseif ($script:step -eq 1) {
    $titleLbl.Text = "Paso 2 de 4 · Opciones de instalacion"
    $bodyLbl.Text = "Carpeta destino: $baseDir"
    $btnNext.Text = "Instalar ahora"
  } elseif ($script:step -eq 2) {
    $titleLbl.Text = "Paso 3 de 4 · Instalando Pan-launcher..."
    $bodyLbl.Text = "Extrayendo archivos y configurando accesos directos..."
    $btnNext.Text = "Instalando..."
  } else {
    $titleLbl.Text = "Paso 4 de 4 · ¡Pan-launcher esta listo!"
    $titleLbl.ForeColor = $emerald
    $bodyLbl.Text = "1. Abre el icono Pan-launcher en tu Escritorio cuando quieras jugar.`r`n2. Elige tu version de Minecraft, mods FPS y cuenta.`r`n3. Pulsa Jugar ahora para descargar Java e iniciar Minecraft Java real."
    $chkLaunch.Top = 250
    $btnNext.Text = "Finalizar y abrir"
  }
}

function Invoke-InstallSteps {
  $script:step = 2
  $prog.Value = 20
  Update-StepUi
  [System.Windows.Forms.Application]::DoEvents()
  try {
    try {
      Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*Pan-launcher*server.ps1*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {}
    New-Item -ItemType Directory -Force -Path $baseDir, $binDir | Out-Null
    $zip = [System.IO.Compression.ZipFile]::OpenRead($bundleZip)
    try {
      foreach ($entry in $zip.Entries) {
        if ([string]::IsNullOrEmpty($entry.Name)) { continue }
        $dest = Join-Path $baseDir ($entry.FullName.Replace("/", "\"))
        $parent = Split-Path -Parent $dest
        if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true)
      }
    } finally { $zip.Dispose() }
    [IO.File]::WriteAllText($verPath, '1795718147255', [Text.Encoding]::UTF8)
    $prog.Value = 70
    [System.Windows.Forms.Application]::DoEvents()

    $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LocalAppData\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    $hostVbs = Join-Path $baseDir "Pan-launcher.vbs"
    $srvCmd = Join-Path $baseDir "start-server.cmd"
    $appUrl = "http://127.0.0.1:41735/"
    $browserExe = if ($edge) { $edge } elseif ($chrome) { $chrome } else { "" }
    $vbsLines = @(
      "Set sh = CreateObject(`"WScript.Shell`")",
      "sh.Run `"`"`"$srvCmd`"`"`", 0, False",
      "WScript.Sleep 650"
    )
    if ($browserExe) {
      $vbsLines += "sh.Run `"`"`"$browserExe`"`" --app=$appUrl --user-data-dir=`"`"$baseDir\appprofile`"`"`", 1, False"
    } else {
      $vbsLines += "sh.Run `"`"$appUrl`"`", 1, False"
    }
    [IO.File]::WriteAllLines($hostVbs, $vbsLines, [Text.Encoding]::ASCII)
    $script:launchCmdTarget = $hostVbs

    $ws = New-Object -ComObject WScript.Shell
    if ($chkDesktop.Checked) {
      $sc = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "Pan-launcher.lnk"))
      $sc.TargetPath = "wscript.exe"
      $sc.Arguments = "`"$hostVbs`""
      $sc.WorkingDirectory = $baseDir
      $sc.Save()
    }
    if ($chkMenu.Checked) {
      $pDir = Join-Path ([Environment]::GetFolderPath("Programs")) "Pan-launcher"
      New-Item -ItemType Directory -Force -Path $pDir | Out-Null
      $sc2 = $ws.CreateShortcut((Join-Path $pDir "Pan-launcher.lnk"))
      $sc2.TargetPath = "wscript.exe"
      $sc2.Arguments = "`"$hostVbs`""
      $sc2.WorkingDirectory = $baseDir
      $sc2.Save()
    }
    $prog.Value = 100
    $script:step = 3
    Update-StepUi
  } catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Error en Pan-launcher", "OK", "Error") | Out-Null
    $script:step = 1
    Update-StepUi
  }
}

$btnBack.Add_Click({ if ($script:step -eq 1) { $script:step = 0; Update-StepUi } })
$btnNext.Add_Click({
  if ($script:step -eq 0) { $script:step = 1; Update-StepUi }
  elseif ($script:step -eq 1) { Invoke-InstallSteps }
  elseif ($script:step -eq 3) {
    if ($chkLaunch.Checked -and $script:launchCmdTarget) {
      Start-Process -FilePath "wscript.exe" -ArgumentList ("`"" + $script:launchCmdTarget + "`"") -WorkingDirectory $baseDir
    }
    $form.Close()
  }
})

Update-StepUi
[void]$form.ShowDialog()
