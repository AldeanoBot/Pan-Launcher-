@echo off
chcp 65001 >nul
title Instalador de Pan-launcher
if not exist "%~dp0app-bundle.zip" (
  powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Primero extrae todo el contenido de este archivo ZIP (clic derecho -> Extraer todo) en una carpeta y luego abre Instalar-Guiado.cmd.', 'Pan-launcher', 'OK', 'Warning')"
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0setup-gui.ps1"
exit /b
